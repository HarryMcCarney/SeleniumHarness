using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;

namespace SeleniumTests
{
    [TestFixture]
    public class LLBuy
    {
        private IWebDriver driver;
        private StringBuilder verificationErrors;
        private string baseURL;
        private bool acceptNextAlert = true;
        
        [SetUp]
        public void SetupTest()
        {
            driver = new FirefoxDriver();
            baseURL = "https://startpage.com/";
            verificationErrors = new StringBuilder();
        }
        
        [TearDown]
        public void TeardownTest()
        {
            try
            {
                driver.Quit();
            }
            catch (Exception)
            {
                // Ignore errors if unable to close the browser
            }
            Assert.AreEqual("", verificationErrors.ToString());
        }
        
        [Test]
        public void TheLLBuyTest()
        {
            String demo = "http://demo.larryslist.de/";
            String dev = "http://dev.larryslist.de/";
            // Speed below 350 results in an Internal Server Error
            // ERROR: Caught exception [ERROR: Unsupported command [setSpeed | 400 | ]]
            driver.Navigate().GoToUrl(baseURL + dev + "logout");
            for (int second = 0;; second++) {
                if (second >= 60) Assert.Fail("timeout");
                try
                {
                    if (IsElementPresent(By.LinkText("Login"))) break;
                }
                catch (Exception)
                {}
                Thread.Sleep(1000);
            }
            driver.FindElement(By.XPath("//div[@id='global-frame']/div/div/div/ul/li[4]/a/span")).Click();
            for (int second = 0;; second++) {
                if (second >= 60) Assert.Fail("timeout");
                try
                {
                    if (IsElementPresent(By.Name("login.email"))) break;
                }
                catch (Exception)
                {}
                Thread.Sleep(1000);
            }
            driver.FindElement(By.Name("login.email")).Clear();
            driver.FindElement(By.Name("login.email")).SendKeys("test@friendfund.com");
            driver.FindElement(By.Name("login.pwd")).Clear();
            driver.FindElement(By.Name("login.pwd")).SendKeys("123");
            driver.FindElement(By.XPath("//button[@type='submit']")).Click();
            for (int second = 0;; second++) {
                if (second >= 60) Assert.Fail("timeout");
                try
                {
                    if (IsElementPresent(By.XPath("//div[@id='global-frame']/div[3]/div[2]/div[2]/div[2]/div[2]/div/ul/li[4]/div/div[5]/p"))) break;
                }
                catch (Exception)
                {}
                Thread.Sleep(1000);
            }
            // ERROR: Caught exception [ERROR: Unsupported command [highlight | //div[@id='global-frame']/div[3]/div[2]/div[2]/div[2]/div[2]/div/ul/li[4]/div/div[5]/p | ]]
            driver.FindElement(By.XPath("//div[@id='global-frame']/div[3]/div[2]/div[2]/div[2]/div[2]/div/ul/li[4]/div/div[5]/p")).Click();
            for (int second = 0;; second++) {
                if (second >= 60) Assert.Fail("timeout");
                try
                {
                    if (IsElementPresent(By.XPath("(//a[contains(text(),'Buy now')])[2]"))) break;
                }
                catch (Exception)
                {}
                Thread.Sleep(1000);
            }
            // ERROR: Caught exception [ERROR: Unsupported command [highlight | xpath=(//a[contains(text(),'Buy now')])[2] | ]]
            // ERROR: Caught exception [ERROR: Unsupported command [highlight | xpath=(//a[contains(text(),'Buy now')])[2] | ]]
            driver.FindElement(By.XPath("(//a[contains(text(),'Buy now')])[2]")).Click();
            for (int second = 0;; second++) {
                if (second >= 60) Assert.Fail("timeout");
                try
                {
                    if (IsElementPresent(By.XPath("//div[@id='global-frame']/div[3]/div[2]/div[2]/div[2]/div[2]/div/ul/li[5]/div/div[5]"))) break;
                }
                catch (Exception)
                {}
                Thread.Sleep(1000);
            }
            // ERROR: Caught exception [ERROR: Unsupported command [highlight | //div[@id='global-frame']/div[3]/div[2]/div[2]/div[2]/div[2]/div/ul/li[5]/div/div[5] | ]]
            for (int second = 0;; second++) {
                if (second >= 60) Assert.Fail("timeout");
                try
                {
                    if (IsElementPresent(By.XPath("//li[4]/a"))) break;
                }
                catch (Exception)
                {}
                Thread.Sleep(1000);
            }
            // ERROR: Caught exception [ERROR: Unsupported command [highlight | //li[4]/a | ]]
            driver.FindElement(By.XPath("//li[4]/a")).Click();
            // ERROR: Caught exception [ERROR: Unsupported command [highlight | link=Logout | ]]
            driver.FindElement(By.LinkText("Logout")).Click();
            for (int second = 0;; second++) {
                if (second >= 60) Assert.Fail("timeout");
                try
                {
                    if (IsElementPresent(By.LinkText("What You Get"))) break;
                }
                catch (Exception)
                {}
                Thread.Sleep(1000);
            }
            // ERROR: Caught exception [unknown command []]
        }
        private bool IsElementPresent(By by)
        {
            try
            {
                driver.FindElement(by);
                return true;
            }
            catch (NoSuchElementException)
            {
                return false;
            }
        }
        
        private string CloseAlertAndGetItsText() {
            try {
                IAlert alert = driver.SwitchTo().Alert();
                if (acceptNextAlert) {
                    alert.Accept();
                } else {
                    alert.Dismiss();
                }
                return alert.Text;
            } finally {
                acceptNextAlert = true;
            }
        }
    }
}
